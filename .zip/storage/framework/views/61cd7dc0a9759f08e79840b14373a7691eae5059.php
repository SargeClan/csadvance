<b>Hello Admin,</b> 

<p>Someone just filled the contact form on your website. Find below the details;</p>

Name: <?php echo e($contact['name']); ?> <br>
Email: <?php echo e($contact['email']); ?> <br>
<b>Subject: <?php echo e($contact['subject']); ?>. </b> <br>
<i>Message: <br> <?php echo e($contact['message']); ?> </i>
<br>
<p>Always keeping you informed of your web activities.</p>
- <a href="https://sargeclan.com">Sarge</a><?php /**PATH C:\xampp\htdocs\projects\csadvance\resources\views/mail/admin_contact.blade.php ENDPATH**/ ?>