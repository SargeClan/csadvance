<b>Hello Sisi,</b>
<br>
<p>Find below details for new loan application;</p>

Name: <?php echo e($userLoan['full_name']); ?> <br>
Phone Number: <?php echo e($userLoan['phone']); ?> <br>
Email: <?php echo e($userLoan['email']); ?> <br>
Loan Amount: <?php echo e($userLoan['amount']); ?> <br>
Repayment Period: <?php echo e($userLoan['repayment']); ?> <br>
Employment Status: <?php echo e($userLoan['employment_status']); ?> <br>
Additional Message: <?php echo e($userLoan['message']); ?> <br>
<br>
<p>Always keeping you informed of your web activities.</p>

- <a href="https://sargeclan.com">Sarge</a>
<?php /**PATH C:\xampp\htdocs\projects\csadvance\resources\views/mail/admin_user_loan.blade.php ENDPATH**/ ?>