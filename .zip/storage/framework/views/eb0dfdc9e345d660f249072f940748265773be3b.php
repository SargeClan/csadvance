<b>Hello <?php echo e($contact['name']); ?>,</b> 

<p><b>We have received your inquiry, one of our representatives will contact you shortly.</b></p>
<p>CSAdvance is a foremost loan company that offers easy and 
swift collateral-free loans within 24 hours at the push of a button.</p>

<p>Getting you to the next level is the reason for our existence.</p>

<p>In the meantime, stay connected with us on social. Follow us on Instagram and Twitter, like our Facebook page.</p>

<p>Do have a great day!</p>
<br>
Love, <br>
<a href="#">Sisi.</a>
<?php /**PATH C:\xampp\htdocs\projects\csadvance\resources\views/mail/contact.blade.php ENDPATH**/ ?>