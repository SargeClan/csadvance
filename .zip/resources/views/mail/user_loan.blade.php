
<b>Hello {{ucfirst($userLoan['full_name'])}},</b> 

<p>Welcome to the next level.</p>
<p>Thanks for choosing us to go on this journey with you.</p>
<p>You are minutes away from achieving your dreams the CSAdvance way.
 One of our representatives will contact you.</p>
<p>In the meantime, stay connected with us on social. Follow us on Instagram and Twitter, like our Facebook page.</p>

<br>
<p>Do have a great day!</p>

<b>Love, <br>Sisi.</b>

