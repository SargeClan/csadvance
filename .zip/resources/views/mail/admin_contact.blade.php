<b>Hello Admin,</b> 

<p>Someone just filled the contact form on your website. Find below the details;</p>

Name: {{$contact['name']}} <br>
Email: {{$contact['email']}} <br>
<b>Subject: {{$contact['subject']}}. </b> <br>
<i>Message: <br> {{$contact['message']}} </i>
<br>
<p>Always keeping you informed of your web activities.</p>
- <a href="https://sargeclan.com">Sarge</a>