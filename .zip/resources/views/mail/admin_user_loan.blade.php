<b>Hello Sisi,</b>
<br>
<p>Find below details for new loan application;</p>

Name: {{$userLoan['full_name']}} <br>
Phone Number: {{$userLoan['phone']}} <br>
Email: {{$userLoan['email']}} <br>
Loan Amount: {{$userLoan['amount']}} <br>
Repayment Period: {{$userLoan['repayment']}} <br>
Employment Status: {{$userLoan['employment_status']}} <br>
Additional Message: {{$userLoan['message']}} <br>
<br>
<p>Always keeping you informed of your web activities.</p>

- <a href="https://sargeclan.com">Sarge</a>
